# -*- coding: utf-8 -*-
"""مایگریشن‌های برنامه listings"""