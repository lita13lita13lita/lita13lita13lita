# کلون کردن پروژه
git clone <repository>
cd propanalyzer

# اجرای با Docker
cd docker
docker-compose up --build

# دسترسی به سرویس‌ها:
# Frontend: http://localhost:3000
# Backend: http://localhost:8000
# AI API: http://localhost:8001